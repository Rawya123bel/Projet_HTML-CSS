// Fonction pour afficher le contenu du panier sur la page
function displayCart() {
    // Récupérer le contenu du panier depuis le stockage local
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Sélectionner l'élément où le contenu du panier sera affiché
    let panierContent = document.getElementById('panier-content');

    // Vérifier si l'élément existe avant de manipuler son contenu
    if (panierContent) {
        // Construire le HTML pour afficher les produits dans le panier
        let html = '<h2>Panier</h2><ul>';

        cart.forEach((product) => {
            html += `<li>${product.productName} - ${product.price} $</li>`;
        });

        html += '</ul>';

        // Injecter le HTML dans l'élément du panier
        panierContent.innerHTML = html;
    }
}

// Appeler la fonction displayCart pour afficher le panier au chargement de la page
document.addEventListener('DOMContentLoaded', displayCart);